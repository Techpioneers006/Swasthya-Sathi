# SwasthyaSathi AI
**Simple Health Triage for Rural & Tier-2 India**

A beginner-friendly full-stack college project built with HTML, CSS, vanilla JavaScript, Node.js and Express. It accepts symptoms by typing or browser speech recognition, gives one of three urgency categories, supports a basic language selector, includes dark mode, and can search nearby facilities when Google Places is configured.

> **Important safety notice:** This is a student software demonstration, not a medical decision system. It does not diagnose disease or prescribe medicine. Demo keyword rules are not medically validated and must not be used to make real healthcare decisions. If you think an emergency is happening, seek immediate professional help instead of waiting for this app.

## Features
- Voice input using the browser Web Speech API (browser and language support varies).
- Text input in English, Hindi, Hinglish and regional scripts.
- Three urgency categories: `HOME_CARE`, `PHC_CLINIC`, `EMERGENCY`.
- Basic emergency-keyword override before any AI call.
- Demo mode works without paid APIs.
- Optional OpenAI-compatible LLM endpoint, configured only on the server.
- Optional Google Places nearby-care search; manual Google Maps fallback always available.
- Responsive layout, keyboard focus states, and dark/light theme.
- No database and no symptom persistence by default. Only theme preference is stored in localStorage.

## Technology
- Frontend: HTML5, CSS3, vanilla JavaScript
- Backend: Node.js 18+, Express
- Security basics: Helmet, CORS, express-rate-limit, input validation, JSON size limit
- Browser API: Web Speech API and geolocation
- Optional services: OpenAI-compatible chat completions endpoint and Google Places API (New)

## Folder structure
```text
swasthya-sathi/
├── frontend/
│   ├── index.html
│   ├── style.css
│   ├── script.js
│   └── assets/
├── backend/
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   ├── routes/
│   │   ├── triage.js
│   │   └── care.js
│   ├── services/
│   │   ├── aiService.js
│   │   └── mapsService.js
│   └── utils/
│       ├── safetyRules.js
│       └── validation.js
├── .gitignore
└── README.md
```

## Requirements
1. Install Node.js 18 or newer from the official Node.js website: https://nodejs.org/
2. Install Visual Studio Code: https://code.visualstudio.com/
3. Optional: Google Maps Platform account/API key for live nearby-care results.
4. Optional: an API key for a compatible LLM endpoint. The project runs without it in demo mode.

## Run in VS Code (Windows)
1. Extract the ZIP file.
2. Open VS Code → **File → Open Folder** → select the `swasthya-sathi` folder.
3. Open **Terminal → New Terminal**.
4. Go to the backend folder:
   ```powershell
   cd backend
   ```
5. Install packages:
   ```powershell
   npm install
   ```
6. Copy the environment template:
   ```powershell
   Copy-Item .env.example .env
   ```
   On Command Prompt, use `copy .env.example .env`.
7. Keep `DEMO_MODE=true` in `.env`.
8. Start the application:
   ```powershell
   npm run dev
   ```
   Or use `npm start`.
9. Open **http://localhost:5000** in Chrome or Edge. The frontend is served by the same Node server; do not use Live Server for this setup.

## Environment configuration
`backend/.env` is local and must never be committed to Git.

```env
PORT=5000
DEMO_MODE=true
LLM_API_KEY=
LLM_BASE_URL=https://api.openai.com/v1
LLM_MODEL=gpt-4o-mini
GOOGLE_MAPS_API_KEY=
CORS_ORIGIN=
```

### Demo mode
- `DEMO_MODE=true` means no external LLM request is made.
- Leave it enabled for a classroom demonstration unless your instructor explicitly asks for live AI integration.
- The emergency keyword override runs before demo or AI processing.
- Demo keyword matching is simplistic and may misclassify language, negation, context, or misspellings. Do not rely on it for real health decisions.

### Optional LLM integration
1. Use an OpenAI-compatible Chat Completions API.
2. Put your provider key in `LLM_API_KEY` in `backend/.env`; never put it in `frontend/script.js` or HTML.
3. Set `LLM_BASE_URL` and `LLM_MODEL` to values supported by your provider.
4. Set `DEMO_MODE=false`.
5. Restart the server.
6. Confirm the provider supports JSON response format. If provider errors or returns invalid JSON, the app uses a conservative PHC/clinic fallback.

LLM responses can be incorrect. This integration is not clinically validated. The safety keyword layer is not a substitute for medical review.

### Optional Google Places integration
1. Enable Places API (New) in Google Maps Platform.
2. Create a restricted API key and configure billing/quotas as required by Google.
3. Put it in `GOOGLE_MAPS_API_KEY` in `backend/.env`.
4. Restart the server and allow location access in the browser.
5. If no key or API results are available, the app will show a message and provide manual Google Maps search.

Do not expose the key in frontend code. Restrict the key and monitor usage.

## API endpoints
### `GET /api/health`
Response: `{ "status": "ok" }`

### `POST /api/triage`
Example request:
```json
{
  "symptoms": "Mild fever and tiredness",
  "age": 24,
  "gender": "Female",
  "pregnancyStatus": "unknown",
  "language": "en"
}
```
Returns urgency, summary, reason, recommended action, warning signs and disclaimer.

### `POST /api/care/search`
Example request:
```json
{"latitude":28.6692,"longitude":77.4538,"type":"hospital"}
```
Returns real Places API results when configured, or an unavailable response. The app does not invent facility names or addresses.

## Test checklist
- Empty symptom text is rejected.
- Mild fever/tiredness sample returns a demo result.
- Headache, fever/vomiting and stomach pain samples can return clinic guidance.
- Severe chest pain/difficulty breathing sample triggers the emergency override.
- Hindi text can be submitted.
- Voice input works only where browser speech recognition is supported and permission is granted.
- Deny microphone permission and verify typing remains available.
- Deny location permission and use manual map search.
- Toggle dark mode.
- Resize to mobile width and check for horizontal scrolling.
- Run without API keys and verify the application still opens.

## College presentation flow
1. Explain the problem: people may need simple guidance about how urgently to seek healthcare.
2. Open the home page and choose Hindi.
3. Demonstrate typing or voice input.
4. Use the severe chest pain/difficulty breathing sample to show the emergency safety override.
5. Explain that this is triage guidance, not a diagnosis.
6. Demonstrate a mild symptom sample.
7. Show the nearby-care location flow and the manual map fallback.
8. Explain limitations: keyword detection is simplistic, AI can be wrong, speech recognition depends on browser support, and live care search needs a configured API.

## Known limitations / future improvements
- Translation is partial; not every sentence is translated into all eight languages yet.
- Keyword demo logic is intentionally simple and is not medically validated.
- Browser speech recognition is not supported in every browser and may rely on network services.
- Live nearby-care search requires Google Places API configuration.
- A production version would require clinical validation, professional oversight, privacy/security review, stronger localization, accessibility testing, monitoring and careful data governance.

## Privacy and safety
- Symptom text is sent to the local backend for processing and is not saved to a database by this app.
- Avoid entering names, phone numbers, addresses or other unnecessary personal information.
- If live LLM mode is enabled, symptom data is sent to the configured external provider; review that provider's terms and privacy practices before use.
- No medical diagnosis, prescriptions or medication dosages are provided.
